package magna.data.colector;

import org.springframework.jdbc.core.JdbcTemplate;

public class TesteBanco {
    public static void main(String[] args) {
        Connector con = new Connector();
        JdbcTemplate banco = con.getConnection();

        banco.execute("DROP TABLE teste.filme IF EXISTS;");
        banco.execute(
            "CREATE TABLE teste.filme ("
                    + "id INT PRIMARY KEY AUTO_INCREMENT,"
                    + "nome VARCHAR(255) NOT NULL,"
                    + "ano_lancamento int NOT NULL"
                    + ");"
        );
    }
}
